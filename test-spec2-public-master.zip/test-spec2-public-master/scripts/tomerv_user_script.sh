echo "creating tomer dir"
mkdir /tomer
echo "creating /tomer/name.txt"
echo "tomer" > /name.txt

echo "install nano"
apt update
apt install nano -y

#cat /wemrwrr/w

